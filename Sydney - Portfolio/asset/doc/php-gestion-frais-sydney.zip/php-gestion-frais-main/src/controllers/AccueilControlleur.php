<?php

namespace Gsb\controllers;

class AccueilControlleur extends Controlleur{

    public function index(){

        $this->render('accueil');
    
    }
}
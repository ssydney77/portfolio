<?php

namespace Gsb\controllers;

class ListeMoisControlleur extends Controlleur{

    public function index(){

        $this->render('listeMois');
    
    }
}
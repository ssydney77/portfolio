<?php

namespace Gsb\controllers;

class ListeFraisForfaitControlleur extends Controlleur{

    
    public function index(){
        
        $this->render('listeFraisForfait');
    
    }
}
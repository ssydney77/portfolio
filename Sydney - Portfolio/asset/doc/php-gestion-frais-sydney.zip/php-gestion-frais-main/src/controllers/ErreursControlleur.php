<?php

namespace Gsb\controllers;

class ErreursControlleur extends Controlleur{

    public function index(){

        $this->render('erreurs');
    
    }
}
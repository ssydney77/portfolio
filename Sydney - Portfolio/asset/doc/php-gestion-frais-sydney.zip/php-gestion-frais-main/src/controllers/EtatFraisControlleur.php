<?php

namespace Gsb\controllers;

class EtatFraisControlleur extends Controlleur{

    public function index(){

        $this->render('etatFrais');
    
    }
}
<?php

namespace Gsb\controllers;

class ConnexionControlleur extends Controlleur{

    public function index(){

        $this->render('connexion');

    }
}


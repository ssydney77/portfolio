<?php

namespace Gsb\controllers;

class ListeFraisHorsForfaitControlleur extends Controlleur{

    public function index(){

        $this->render('listeFraisHorsForfait');
    
    }
}
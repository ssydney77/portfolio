<div class="container text-center">
      <div class="login-form py-5">
            <h2>Identification utilisateur</h2>
            <form method="post" action="connexion">
                  <section>
                        <div class="py-2">
                              <input type="text" name="login" placeholder="Login">
                        </div>
                        <div class="py-2">
                              <input type="password" name="mdp" placeholder="Password">
                        </div>
                  </section>      
                  <div class="container">
                        <button class="valider m-2" type="submit" name="valider">Valider</button>
                        <button class="annuler m-2" type="reset" name="annuler">Annuler</button>
                  </div>
            </form>
      </div>
</div>